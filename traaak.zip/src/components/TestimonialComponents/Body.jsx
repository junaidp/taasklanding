import React from "react";
import "./index.css";
// import { testimonial } from "./data";

const Body = () => {
  return (
    <div>
      <div className="testimonialMain">
        {/*  */}
        <div className="testimonialCard card1">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla.
          </p>
          <div className="testimonialBox">
            {/* <div className="testimonialBigSmall"> */}
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            {/* </div> */}
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
        {/*  */}
        <div className="testimonialCard card2">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla nisl eros, quis congue orci sollicitudin id.
            Nam erat eros, sagittis sed dolor nec, condimentum.
          </p>
          <div className="testimonialBox">
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
        {/*  */}
        <div className="testimonialCard card3">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla nisl eros, quis congue orci.
          </p>
          <div className="testimonialBox">
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
        {/*  */}
        <div className="testimonialCard card4">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla nisl eros, quis congue orci sollicitudin id.
            Nam erat eros, sagittis sed dolor nec, condimentum.
          </p>
          <div className="testimonialBox">
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
        {/*  */}
        <div className="testimonialCard card5">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla nisl eros, quis congue orci.
          </p>
          <div className="testimonialBox">
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
        {/*  */}
        <div className="testimonialCard card6">
          <p>
            Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis.
            Donec arcu dolor, bibendum non massa in, fermentum mollis libero.
            Pellentesque fringilla
          </p>
          <div className="testimonialBox">
            <div className="testimonialBoxSmall">
              <h1>BK</h1>
            </div>
            <div>
              <h2>Billy Kane</h2>
              <h3>CEO & Founder</h3>
            </div>
          </div>
        </div>
        {/*  */}
      </div>
      <button className="homeBtnCommon testimonialBtn">Load More</button>
    </div>
  );
};

export default Body;
