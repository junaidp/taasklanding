let testimonial = [
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla nisl eros, quis congue orci sollicitudin id. Nam erat eros, sagittis sed dolor nec, condimentum.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla nisl eros, quis congue orci.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla nisl eros, quis congue orci sollicitudin id. Nam erat eros, sagittis sed dolor nec, condimentum.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla nisl eros, quis congue orci.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
  {
    para: "Nam ut consequat elit. Ut feugiat ex sit amet viverra lobortis. Donec arcu dolor, bibendum non massa in, fermentum mollis libero. Pellentesque fringilla.",
    name: "Billy Kane",
    field: "CEO & Founder",
  },
];

export { testimonial };
