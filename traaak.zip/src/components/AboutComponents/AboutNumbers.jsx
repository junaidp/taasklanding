import React from 'react'
import "./AboutNumber.css"

const AboutNumbers = () => {
  return (
    <div>
      
    </div>
  )
}

export default AboutNumbers
