import AboutContent from "./AboutContent";
import AboutNumbers from "./AboutNumbers";
import TimeLine from "./TimeLine";
import Companies from "./Componies";

export { AboutNumbers, AboutContent, TimeLine, Companies };
