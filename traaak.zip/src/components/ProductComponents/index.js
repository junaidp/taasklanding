import ProductHeader from "./ProductHeader";
import ProductNumbers from "./ProductNumbers";
import ProductContent from "./ProductContent";
import Vedio from "./Vedio";
import Map from "./Map";

export { ProductHeader, ProductNumbers, ProductContent, Vedio, Map };
