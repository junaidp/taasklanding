import Home from "./Home";
import About from "./About";
import Pricing from "./Pricing";
import Testimonial from "./Testimonial";
import Blog from "./Blog";
import Product from "./Product";

export { Home, About, Pricing, Testimonial, Blog, Product };
